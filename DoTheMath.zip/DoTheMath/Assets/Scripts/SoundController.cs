﻿using UnityEngine;
using System.Collections;

public class SoundController : MonoBehaviour {

	public static SoundController SC;

	public AudioClip jump,bounce,timer,loseSound,winSound;
	public float jumpVolume,bounceVolume,timerVolume,loseSoundVolume,winSoundVolume;
	public Vector3 position;
	public bool isJump;

	private AudioListener audioListener;
	private AudioSource timerSource,bounceSource,loseSoundSource,winSoundSource;

	// Add audio listener
	// Add timer source
	// Add bounce source
	// Add loseSound source
	// Add winSound source
	void Start () {

		SC = gameObject.GetComponent<SoundController> ();
		
		audioListener = gameObject.AddComponent<AudioListener> ();

		timerSource = gameObject.AddComponent<AudioSource> ();
		timerSource.clip = timer;
		timerSource.volume = timerVolume;

		bounceSource = gameObject.AddComponent<AudioSource> ();
		bounceSource.clip = bounce;
		bounceSource.volume = bounceVolume;
		bounceSource.loop = true;

		loseSoundSource = gameObject.AddComponent<AudioSource> ();
		loseSoundSource.clip = loseSound;
		loseSoundSource.volume = loseSoundVolume;
		loseSoundSource.enabled = false;

		winSoundSource = gameObject.AddComponent<AudioSource> ();
		winSoundSource.clip = winSound;
		winSoundSource.volume = winSoundVolume;
		winSoundSource.enabled = false;

		isJump = false;
	}

	// jump sound
	void Update () {
		if (isJump)
		{
			AudioSource.PlayClipAtPoint (jump, gameObject.transform.position, jumpVolume);
			isJump = false;
		}
	
	}

	public void PlayTimer()
	{
		timerSource.enabled = false;
		timerSource.enabled = true;
	}

	public void StopTimer()
	{
		timerSource.enabled = false;
	}

	public void PlayBounce()
	{
		bounceSource.enabled = false;
		bounceSource.enabled = true;
	}

	public void StopBounce()
	{
		bounceSource.enabled = false;
	}
		
	public void PlayLose()
	{
		loseSoundSource.enabled = false;
		loseSoundSource.enabled = true;
	}

	public void PlayWin()
	{
		winSoundSource.enabled = false;
		winSoundSource.enabled = true;
	}
}
