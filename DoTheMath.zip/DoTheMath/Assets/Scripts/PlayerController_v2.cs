﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI; // for UI text

public class PlayerController_v2 : MonoBehaviour {

	public float speed;
	public float jumpStrength;
	public float bouncingStrength;
	public float bouncingRate;
	public float gravity;
	public bool onFloor;
	public bool hitWall;
	public float jumpSoundVolume;
	public float bounceWallHorizontalStrength;
	public float bounceWallVerticalStrength;

	private Rigidbody2D rb2d;
	private float moveHorizontal;
	private float tt;
	private Quaternion target;

	void Start()
	{
		onFloor = false;
		hitWall = false;
		rb2d = GetComponent<Rigidbody2D> ();
		tt = Time.time;
	}

	// move player
	// sound: jump, bounce
	void FixedUpdate()
	{

		// no rotation Z
		rb2d.freezeRotation = true;

		// flip player facing the moving direction (rotate Y)
		float x = Input.GetAxis ("Horizontal");
		if (x < 0) 
			target = Quaternion.Euler(0, 180, 0); // facing left
		else if (x > 0)
			target = Quaternion.Euler(0, 0, 0); // facing right
		transform.rotation = target; // facing left

		// move horizontal
		moveHorizontal = Input.GetAxis ("Horizontal") * speed;
		rb2d.velocity = new Vector2 (moveHorizontal,0);

		// bouncing
		// do it only on floor
		if (onFloor)
		{
			if (Time.time>tt)
			{
				rb2d.AddForce(new Vector2 (0,bouncingStrength) );
				tt = Time.time + bouncingRate;
			}	
		}

		// jump (move vertical)
		// do it only on floor
		// onFloor = false after jump
		if ((Input.GetButtonDown ("Jump") || Input.GetButtonDown ("Fire1") || Input.GetButtonDown ("Vertical"))) 			
		{
			if (onFloor)			
			{
				rb2d.AddForce(new Vector2 (0,jumpStrength) );
				SoundController.SC.isJump = true;
				onFloor = false;
			}
		}

		// drop speed after jump
		if (!onFloor)
		{
			rb2d.AddForce(new Vector2 (0,-gravity) );
		}

		// if hit wall, move player back
		// NOTE: this attempts to fix bug from colliding on the wall and the player keeps raising up.
		if (hitWall)
		{
			Vector3 p = transform.position;
			moveHorizontal = Input.GetAxis ("Horizontal") * bounceWallHorizontalStrength;
			p += new Vector3 (-moveHorizontal, -bounceWallVerticalStrength, 0);
			transform.position = p;
			onFloor = true;
			hitWall = false;
		}
			
	}

	//detect on floor
	//detect input
	//detect hit walls
	void OnCollisionEnter2D(Collision2D coll)
	{
		
		// on floor
		if (coll.gameObject.tag == "Floor")
		{
			onFloor = true;
		}

		// input
		// only if not in the win,lose stage
		if (coll.gameObject.tag == "CubeNum")
		{
			if (!GameManager_v2.gm.win && !GameManager_v2.gm.lose) 
			{
				string tt = coll.gameObject.GetComponentInChildren<TextMesh>().text;
				GameManager_v2.textInput.text = tt;
				GameManager_v2.gm.CompareInput ();
			}
		}

		if (coll.gameObject.tag == "Wall")
		{
			onFloor = false;
			hitWall = true;
		}

	}

}
