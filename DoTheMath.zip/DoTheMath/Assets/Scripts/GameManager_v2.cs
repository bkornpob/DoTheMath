﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager_v2 : MonoBehaviour {

	public static GameManager_v2 gm;
	public static Text textInput;

	public float timeout;
	public float timeToNextPuzzle;
	public int gameNumberToClearLevel;
	public Text textOperand1, textOperand2, textOperator, textTime, textResult;
	public TextMesh[] textCube;//,textCube2,textCube3,textCube4,textCube5,textCube6,textCube7,textCube8,textCube9,textCube10
	public GameObject player;
	public bool win;
	public bool lose;

	private int operand1,operand2;
	private char result;
	private char op;
	private float tt;
	private int gameNumber=0;

	void Start () 
	{
		gm = gameObject.GetComponent<GameManager_v2> ();
		textInput = GameObject.FindWithTag("Input").GetComponent<Text>();

		GeneratePuzzle ();
		PrintPuzzle ();
		GenerateCube ();
		textInput.text="???";

		tt = timeout;

		Invoke ("PlaySound", 0);

		win = false;
		lose = false;
		gameNumber += 1;

		if (gameNumber > gameNumberToClearLevel) 
		{
			Application.Quit ();
		}
	}

	void PlaySound()
	{
		SoundController.SC.PlayTimer();
		SoundController.SC.PlayBounce();		
	}

	char[] Shuffle(char[] allowNumber)
	{
		int ll = allowNumber.Length;
		for (int i=0;i<ll;i++)
		{
			int index = Random.Range (i,ll);
			char temp = allowNumber [i];
			allowNumber [i] = allowNumber [index];
			allowNumber [index] = temp;
		}

		return allowNumber;
	}
	void GenerateCube()
	{
		// define allowed integer
		char[] allowNumber = { '<', '=', '>' };

		// permute
		allowNumber = Shuffle(allowNumber);

		// assign to text cubes
		int ll=textCube.Length;
		for (int ii = 0; ii < ll; ii++) 
		{
			textCube [ii].text = allowNumber [ii].ToString ();
		}
	}

	void GeneratePuzzle()
	{

		// Define possible operator
		char[] allowOperator = {'>','<','='};

		// Randomly pick operator
		int num = Random.Range(0,3); // inclusive lower limit, exclusive upper limit
		result=allowOperator[num];
		
		// Pick operands
		bool sent=true;
		switch (result) 
		{
		case '=':
			operand1 = Random.Range (-100, 101);
			operand2 = operand1;
			break;
		case '>':
			do {
				operand1 = Random.Range (-100, 101);
				operand2 = Random.Range (-100, 101);
				if (operand1 > operand2)
					sent = !sent;
			} while(sent);
			break;
		case '<':
			do
			{
				operand1 = Random.Range (-100, 101);
				operand2 = Random.Range (-100, 101);
				if (operand1 < operand2) 
					sent = !sent;
			} while(sent);
			break;
		}
			
	}

	// Output on canvas
	void PrintPuzzle()
	{

		// Input value
		textOperand1.text = operand1.ToString();
		textOperand2.text = operand2.ToString();
		textResult.text = result.ToString ();

	}
		
	void Update()
	{

		// Update time
		if (win == false && lose == false)
		{
			if (tt > 0) {
				tt -= Time.deltaTime;
				ShowTime ();
			} else {
				tt = 0;
				Loser ();
			}
		}

	}

	void ShowTime()
	{
		textTime.text = tt.ToString ("0.00");
	}

	// Call when lose the game
	void Loser()
	{
		lose = true;
		textTime.text = "You suck!!!";
		SoundController.SC.StopTimer ();
		SoundController.SC.StopBounce ();
		SoundController.SC.PlayLose ();
		Invoke ("Start",timeToNextPuzzle);
	}

	public void CompareInput()
	{
		if (!win && !lose) {
			if (textInput.text == textResult.text) {
				{
					WinLevel ();
				}
			} else
				Loser ();
		}

	}

	void WinLevel()
	{
		win = true;
		textTime.text = "Awesome!!!";
		SoundController.SC.StopTimer ();
		SoundController.SC.StopBounce ();
		SoundController.SC.PlayWin ();
		Invoke ("Start",timeToNextPuzzle);
	}
		
}
