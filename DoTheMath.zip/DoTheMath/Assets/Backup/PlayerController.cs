﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI; // for UI text

public class PlayerController : MonoBehaviour {

	public float speed;
	public float jumpStrength;

	private Rigidbody2D rb2d;
	private bool onFloor;

	void Start()
	{
		rb2d = GetComponent<Rigidbody2D> ();
		onFloor = false;
	}

	void Update()
	{
		// Move horizontal
		float moveHorizontal = Input.GetAxis ("Horizontal") * Time.deltaTime * speed;

		// Jump
		// cannot jump if not on floor
		float moveVertical = 0;
		if ( (Input.GetButtonDown ("Jump") || Input.GetButtonDown ("Fire1") || Input.GetButtonDown ("Vertical")) && onFloor ) 
		{
			moveVertical = jumpStrength;
			onFloor = false;
		}
			
		Vector2 movement = new Vector2 (moveHorizontal, moveVertical);
		rb2d.AddForce (movement);
	}
		
	void OnCollisionEnter2D(Collision2D coll)
	{
		// activate jump if on floor
		if (coll.gameObject.tag == "Floor")
		{
			onFloor = true;
		}
	}
		

}
