﻿using UnityEngine;
using System.Collections;

public class PlayerInput : MonoBehaviour {

	void OnCollisionEnter2D(Collision2D coll)
	{
		if (coll.gameObject.tag == "CubeNum")
		{
			string tt = coll.gameObject.GetComponentInChildren<TextMesh>().text;
			if (GameManager.textInput.text == "???") 
			{
				if (tt != '0'.ToString()) 
				{
					GameManager.textInput.text = tt;
				}
			} 
			else 
			{
				GameManager.textInput.text += tt;
			}
		}

		if (coll.gameObject.tag == "CubeClear") 
		{
			GameManager.textInput.text = "???";
		}

		if (coll.gameObject.tag == "CubeOK") 
		{
			GameManager.gm.CompareInput ();
		}
	}

}
