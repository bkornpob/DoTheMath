﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

	public static GameManager gm;
	public static Text textInput;
	public float timeout;
	public float timeToNextPuzzle;
	public int gameNumberToClearLevel;
	public Text textOperand1, textOperand2, textOperator, textTime, textResult;
	public TextMesh[] textCube;//,textCube2,textCube3,textCube4,textCube5,textCube6,textCube7,textCube8,textCube9,textCube10

	private int operand1,operand2,result;
	private char op;
	private float tt;
	private bool win;
	private bool lose;
	private int gameNumber=0;


	void Start () 
	{
		gm = gameObject.GetComponent<GameManager> ();
		textInput = GameObject.FindWithTag("Input").GetComponent<Text>();
		GeneratePuzzle ();
		PrintPuzzle ();
		GenerateCube ();
		textInput.text="???";
		tt = timeout;
		win = false;
		lose = false;
		gameNumber += 1;
		if (gameNumber > gameNumberToClearLevel) 
		{
			Application.Quit ();
		}
	}

	void GenerateCube()
	{
		// define allowed integer
		char[] allowNumber = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

		// permute

		// assign to text cubes
		int ll=textCube.Length;
		for (int ii = 0; ii < ll; ii++) 
		{
			textCube [ii].text = allowNumber [ii].ToString ();
		}
	}

	void GeneratePuzzle()
	{
		
		// Define allowed operator
		char[] allowOperator = {'+','-','*','/'};

		// Randomly pick operator
		int num = Random.Range(0,4); // inclusive lower limit, exclusive upper limit
		op=allowOperator[num];

		// Pick result
		result = Random.Range(1,100); // pick result int 1-99 inclusive

		// Pick operand2 (conditioned by operator)
		switch (op) 
		{
			case '+':
			case '-':
				operand2 = Random.Range (0, 51);
				break;
			case '*':
			case '/':
				operand2 = Random.Range (1, 21);
				break;
		}

		// Pick operand1 = result inv(operator) operand2
		switch (op) 
		{
			case '+':
				operand1 = result - operand2;
				break;
			case '-':
				operand1 = result + operand2;
				break;
			case '*':
				operand1 = Mathf.FloorToInt (result / operand2);
				result = operand1 * operand2; // re-assign result
				break;
			case '/':
				operand1 = result * operand2;
				break;
		}

		if (result == 0)
			GeneratePuzzle ();
	}

	// Output on canvas
	void PrintPuzzle()
	{

		// Input value
		textOperand1.text = operand1.ToString();
		textOperand2.text = operand2.ToString();
		textOperator.text = op.ToString ();
		textResult.text = result.ToString ();

	}

	// Update time
	void Update()
	{
		if (win == false && lose == false)
		{
			if (tt > 0) {
				tt -= Time.deltaTime;
				ShowTime ();
			} else {
				tt = 0;
				Loser ();
			}
		}
	}

	void ShowTime()
	{
		textTime.text = tt.ToString ("0.00");
	}

	// Call when lose the game
	void Loser()
	{
		lose = true;
		textTime.text = "You suck!!!";
		Invoke ("Start",timeToNextPuzzle);
	}

	public void CompareInput()
	{
		if (textInput.text == GameManager.gm.textResult.text) 
		{
			if (lose == false) 
			{
				WinLevel ();
			}
		}
	}

	void WinLevel()
	{
		win = true;
		textTime.text = "Awesome!!!";
		Invoke ("Start",timeToNextPuzzle);
	}
		
}
