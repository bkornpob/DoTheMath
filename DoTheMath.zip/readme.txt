DoTheMath
v1.0.0
Developed under Unity 5.4.2f2, Windows
------------------------------------------------
Team
KB: Designer, Manager, Programmer
Brian Ambrose: Audio
Marco Omta: Artist
------------------------------------------------
Last test: 2017-02-21, normal behaviour in 1920x1080
------------------------------------------------
Known bugs:
Other resolution modes might cause the UI is not shown properly.
In most cases, player keeps moving to the wall will cause the player to float. This is partially fixed by applying PlayerController_v2.bounceWallHorizontal=0.2, PlayerController_v2.bounceWallVertical=0.1, and bool PlayerController_v2.hitWall.
In rare cases, player keeps jumping can cause the player floating in the air.
Because of the quick movement, player might not see the character jumping.
------------------------------------------------
How to use:

In Game manager, it has <GameManager_v2> of which the following list can be changed,
timeout = time in seconds to solve for each puzzle (Default = 5 sec)
timeToNextPuzzle = time in between each puzzle (Default = 1 sec)
gameNumberToClearLevel = number of puzzles before the game ends (Default = 10 puzzles)
void Winlevel() is called if (win)
void Loser() is called if (lose)

Other public variables in any script are not subjected for changing unless necessary.
------------------------------------------------
If there is any problem, please contact KB.
------------------------------------------------
PS To the Over World Team, thank you very much.